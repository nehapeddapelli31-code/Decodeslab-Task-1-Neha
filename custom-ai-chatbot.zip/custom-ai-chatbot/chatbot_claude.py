"""
Custom AI Chatbot with Memory — Claude (Anthropic) Variant
DecodeLabs — Generative AI Project 1
--------------------------------------
Same stateful architecture, wired to the Anthropic SDK instead of OpenAI.
Swap DEFAULT_MODEL and client init to switch between providers.
"""

import os
import uuid
import time
from datetime import datetime
import anthropic


# ── Config ──
DEFAULT_MODEL       = "claude-sonnet-4-6"
MAX_HISTORY_TURNS   = 20
MAX_TOKENS_ESTIMATE = 3000
SYSTEM_PROMPT       = (
    "You are a helpful, intelligent AI assistant. "
    "You remember everything the user has told you in this session. "
    "Be concise, accurate, and friendly."
)


class C:
    RESET  = "\033[0m";  BOLD   = "\033[1m"
    BLUE   = "\033[94m"; GREEN  = "\033[92m"
    YELLOW = "\033[93m"; RED    = "\033[91m"
    CYAN   = "\033[96m"; GRAY   = "\033[90m"


class SessionMetadata:
    def __init__(self):
        self.session_id = str(uuid.uuid4())[:8].upper()
        self.started_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.turn_count = 0

    def increment(self):
        self.turn_count += 1

    def display(self):
        print(f"{C.GRAY}  [SESSION {self.session_id}]  Turn: {self.turn_count}  Started: {self.started_at}{C.RESET}")


def validate_input(text: str) -> bool:
    return bool(text and text.strip())


def apply_sliding_window(history: list, max_turns: int, max_tokens: int) -> list:
    max_messages = max_turns * 2
    while len(history) > max_messages:
        history = history[2:]
    estimated = sum(len(m["content"]) for m in history) // 4
    while estimated > max_tokens and len(history) >= 2:
        history = history[2:]
        estimated = sum(len(m["content"]) for m in history) // 4
    return history


def chat_turn_claude(client: anthropic.Anthropic, history: list, user_msg: str) -> str:
    """
    Anthropic SDK uses the same role-content schema.
    system prompt is passed as a top-level 'system' parameter (not a message).
    """
    history.append({"role": "user", "content": user_msg})

    response = client.messages.create(
        model=DEFAULT_MODEL,
        max_tokens=1024,
        system=SYSTEM_PROMPT,
        messages=history,
    )

    assistant_msg = response.content[0].text
    history.append({"role": "assistant", "content": assistant_msg})
    return assistant_msg


def main():
    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if not api_key:
        print(f"{C.RED}[ERROR] Set ANTHROPIC_API_KEY environment variable.{C.RESET}")
        return

    client  = anthropic.Anthropic(api_key=api_key)
    session = SessionMetadata()
    history: list = []

    print(f"\n{C.BOLD}{C.CYAN}{'═'*55}")
    print("   CUSTOM AI CHATBOT WITH MEMORY (Claude Variant)")
    print(f"{'═'*55}{C.RESET}")
    print(f"{C.GRAY}   Session: {session.session_id}  |  Model: {DEFAULT_MODEL}")
    print(f"   Commands: 'quit' | 'history' | 'clear'{C.RESET}\n")

    while True:
        try:
            user_input = input(f"{C.BOLD}{C.BLUE}You: {C.RESET}").strip()
        except (KeyboardInterrupt, EOFError):
            print(f"\n{C.GRAY}  Goodbye!{C.RESET}")
            break

        if user_input.lower() == "quit":
            break
        elif user_input.lower() == "history":
            for msg in history:
                role  = "You" if msg["role"] == "user" else " AI"
                color = C.BLUE if msg["role"] == "user" else C.GREEN
                print(f"{color}  [{role}] {msg['content'][:120]}{C.RESET}")
            print()
            continue
        elif user_input.lower() == "clear":
            history = []
            print(f"{C.YELLOW}  [CLEARED]{C.RESET}\n")
            continue

        if not validate_input(user_input):
            print(f"{C.YELLOW}  [GATE] Empty input blocked.{C.RESET}\n")
            continue

        history = apply_sliding_window(history, MAX_HISTORY_TURNS, MAX_TOKENS_ESTIMATE)

        try:
            response = chat_turn_claude(client, history, user_input)
            session.increment()
        except Exception as e:
            print(f"{C.RED}  [API ERROR] {e}{C.RESET}\n")
            if history and history[-1]["role"] == "user":
                history = history[:-1]
            continue

        print(f"{C.GREEN}{C.BOLD}AI : {C.RESET}{C.GREEN}{response}{C.RESET}\n")
        session.display()


if __name__ == "__main__":
    main()
